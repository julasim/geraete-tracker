# Handoff: Geräte-Tracker — Oberfläche Handy und Computer

## Überblick

Der Geräte-Tracker verfolgt Baustellengeräte per Code-128-Etikett: scannen, ausgeben,
zurücknehmen, umbuchen, mit lückenloser Historie. Bestehender Stand: Vue 3.5 + Vite +
Pinia + vue-router, mobile-first, Navigation unten, ~200 Geräte, 5–10 Benutzer,
self-hosted auf einem Mini-PC (Caddy + App + Postgres).

Dieses Paket enthält zwei Dinge:

1. **Rekonstruktion der bestehenden Handy-Oberfläche** (14 Ansichten) — abgezeichnet aus
   `web/src/views/*.vue`, `web/src/components/*.vue`, `web/src/styles/tokens.css` und
   `basis.css`. Sie dient als Referenz und Abnahmegrundlage, **nicht** als Änderungsauftrag:
   diese Ansichten existieren im Code bereits so.
2. **Neuentwurf der Computer- und iPad-Oberfläche** (9 Ansichten) — die zu bauende Arbeit.
   Dieselben Funktionen, andere Haltung: Sidebar statt unterer Leiste, dichte Tabelle mit
   Mehrfachauswahl statt Kartenliste, Dialoge über der Liste statt eigener Formularseiten.

## Zu den Design-Dateien

Die Dateien in `design/` sind **Design-Referenzen in HTML** — Prototypen, die Aussehen und
Verhalten zeigen. Sie sind **kein** Produktionscode zum Kopieren. Aufgabe ist, diese Entwürfe
in der bestehenden Umgebung des Projekts nachzubauen: **Vue 3 SFCs unter `web/src/views/`
bzw. `web/src/components/`**, mit den vorhandenen `pt-`-Klassen aus
`web/src/styles/basis.css` und den Tokens aus `web/src/styles/tokens.css`. Keine neue
CSS-Architektur, kein zusätzliches UI-Framework, keine neuen Farben.

Die HTML-Prototypen benutzen absichtlich exakt dieselben Klassennamen wie das Projekt
(`pt-btn`, `pt-btn--primaer`, `pt-feld`, `pt-karte`, `pt-liste`, `pt-zeile`,
`pt-zeile__haupt`, `pt-zeile__titel`, `pt-zeile__unter`, `pt-chip pt-chip--*`,
`pt-meldung pt-meldung--*`, `pt-mikro`, `pt-mono`, `pt-gedaempft`, `pt-leer`, `pt-label`).
Wo im Prototyp Inline-Styles stehen, entspricht das dem `<style scoped>`-Block der jeweiligen
Vue-Ansicht.

**Wichtig, aus der Projekthistorie (AP18/AP19):** Erfundene Klassennamen und erfundene
CSS-Variablen sind in diesem Projekt schon zweimal stumm durchgerutscht — weder `vue-tsc`
noch ESLint sehen sie. Nach dem Bauen `npm run pruefe:oberflaeche` laufen lassen; das Skript
prüft genau das (und außerdem, dass keine schreibende Route ohne Bedienung bleibt).

## Fidelity

**Hi-Fi.** Farben, Typografie, Abstände, Radien und Statusfarben sind final und stammen
vollständig aus `tokens.css`. Bitte pixelgenau umsetzen. Ausnahme: Fotoflächen sind
Platzhalter (`<image-slot>`), im echten Bild stehen dort `GET /api/dateien/:id`.

## Ansichten — Handy (Rekonstruktion, existiert bereits)

Datei: `design/Geräte-Tracker Bestand Mobil.dc.html`, Rahmen 390 px breit.

| ID | Ansicht | Quelle im Code |
|---|---|---|
| 1a | Anmelden | `views/AnmeldeView.vue` |
| 1b | Scannen, Kamera läuft | `views/ScanView.vue` |
| 1c | Scannen, Kamera abgelehnt → Handeingabe mit Vorschlägen | `views/ScanView.vue` + `composables/useScanner.ts` |
| 1d | Scan-Treffer mit Prüfwarnung und erlaubten Aktionen | `views/ScanView.vue` |
| 1e | Sammelmodus mit gesammelten Geräten | `views/ScanView.vue` |
| 1f | Geräteliste mit Suche und Statusfilter | `views/GeraeteView.vue` |
| 1g | Gerätedetail (Titelbild, Aktionen, Galerie, Zubehör, Stammdaten, Prüfungen, Verlauf) | `views/GeraetView.vue` + `components/DateiGalerie.vue` |
| 1h | Ausgeben — Formular | `views/BuchenView.vue` |
| 1i | Ausgeben — Bestätigung | `views/BuchenView.vue` |
| 1j | Sammelausgabe | `views/SammelBuchenView.vue` |
| 1k | Orte, ein Ort aufgeklappt, Regalplätze | `views/OrteView.vue` |
| 1l | Etiketten drucken (Warnhinweis, Vorrat, Bogen, Auswahl, Fußleiste) | `views/EtikettenView.vue` |
| 1m | Gerät anlegen (Erfassen in Folge) | `views/GeraetNeuView.vue` |
| 1n | Mehr/Übersicht mit Kennzahlen, Fristen, Verwaltung, Konto | `views/MehrView.vue` |

Rahmenmaße der bestehenden Shell (`components/AppShell.vue`, `components/Kopf.vue`):

- Kopfzeile: `position: sticky; top: 0`, `min-height: 52px` (`--kopf-hoehe`), Padding
  `12px 16px`, `background: var(--surface)`, `border-bottom: 1px solid var(--border)`.
  Titel 18 px / 600 / `letter-spacing: -0.015em`, Unterzeile 13 px `--fg-muted`.
  Zurück-Knopf 48 × 48, `margin-left: -12px`.
- Untere Leiste: `position: fixed`, Höhe `60px + env(safe-area-inset-bottom)`
  (`--leiste-hoehe`), `grid-template-columns: repeat(4, 1fr)`, Icon 22 px, Label 11 px / 500.
  Inaktiv `--fg-muted` (nicht `--fg-subtle`: 2,6 : 1 wäre bei Sonnenlicht unlesbar),
  aktiv `--fg`.
- Inhaltsbreite `max-width: var(--container)` = 780 px, ab 720 px `padding: 0 16px`.
- Tippziele mindestens **48 px** (`--tippziel`) — Daumen, teils mit Arbeitshandschuhen.
- Eingabefelder mindestens **16 px** Schriftgröße, sonst zoomt iOS beim Fokussieren hinein.

## Ansichten — Computer und iPad (Neuentwurf, zu bauen)

Datei: `design/Geräte-Tracker Desktop.dc.html`, Rahmen 1440 × 900 (2i: 1024 × 768).

### Gemeinsames Layout

- **Sidebar** links, `width: 240px`, `flex: none`, volle Höhe.
  Bleibt in beiden Modi dunkel: `background #0f0f11`, `border-right: 1px solid #27272a`.
  Kopf 56 px hoch, `border-bottom: 1px solid #1d1d20`, Scan-Icon 20 px in `#f4f4f5`,
  Titel „Geräte-Tracker“ 14 px / 600 / `-0.015em`, darunter Mandant 11 px `#71717a`.
  Nav-Bereich `padding: 16px 8px`, Gruppen mit `gap: 16px`.
  Gruppenlabel 11 px / 600 / `letter-spacing: 0.08em` / uppercase / `#52525b`,
  `padding: 0 8px 6px`.
  Nav-Eintrag: Höhe 36 px, `padding: 0 8px`, `border-radius: 6px` (`--radius-md`),
  13 px / 500, Icon 16 px mit `opacity: .8` und `stroke-width: 1.5`, `gap: 10px`.
  Inaktiv `#a1a1aa` auf transparent, aktiv `#f4f4f5` auf `#1f1f23`. Hover: nur Farbe.
  Zähler-Pill bei „Prüfungen“: 11 px / 600, tabular-nums, `padding: 1px 6px`,
  `border-radius: 9999px`, `color #f87171`, `background #2a0d0d`.
  Fuß: Trennlinie `#1d1d20`, Initialen-Kreis 28 px auf `#27272a`, Name 13 px `#e4e4e7`,
  Rolle 11 px `#71717a`, Logout-Icon 16 px `#71717a`.
  Gruppen: **BESTAND** (Übersicht, Geräte, Orte und Regale, Prüfungen, Pakete) ·
  **VERWALTUNG** (Etiketten, Import und Export, Schlagworte und Prüfarten,
  Benutzer und Rollen).
- **Topbar** rechts daneben: Höhe konstant **56 px**, `padding: 0 24px`,
  `background: var(--surface)`, `border-bottom: 1px solid var(--border)`,
  `display: flex; align-items: center; gap: 16px`.
  Seitentitel 20 px / 600 / `-0.015em` `--fg`, Zusatzangabe 13 px `--fg-muted`,
  Aktionsknöpfe `min-height: 36px`, `font-size: 13px`.
- **Inhalt**: `padding: 24px`, Karten `--radius-lg`/`--radius-xl` mit
  `1px solid var(--border)`, kein Schatten außer bei Dialogen.
- Icons durchgängig Feather-Stil, `viewBox 0 0 24 24`, `fill none`,
  `stroke currentColor`, `stroke-width 1.5` (Nav/Topbar) bzw. `1.75` (Aktionen),
  `stroke-linecap/linejoin round`. Keine Emoji, keine Unicode-Glyphen.

### 2a Übersicht (`/` bzw. neue Startseite am Desktop)

- Kennzahlenreihe: `grid-template-columns: repeat(5, 1fr)`, `gap: 16px`, Karte
  `padding: 16px`, Zahl 30 px / 600 / tabular-nums / `-0.015em`, Label 13 px `--fg-muted`.
  Warnzahlen (`Prüfungen überfällig`, `Rückgabe überschritten`) in `--danger-fg`.
  Quellen: `GET /api/geraete` (Store), `GET /api/pruefungen/faellig`,
  `GET /api/buchungen/offen`.
- Zwei Karten darunter, `grid-template-columns: 1.15fr 1fr`, `gap: 24px`:
  **Prüfungen stehen an** (Kartenkopf 16 px/20 px Padding, Titel 15 px / 600, rechts
  Anzahl 13 px `--fg-muted`; Zeilen `pt-zeile` mit `padding: 12px 20px`, Chip rechts:
  `pt-chip--defekt` bei überfällig, `pt-chip--warnung` sonst, Restfrist in Worten —
  „seit 12 Tagen“, „in 9 Tagen“) und **Derzeit draußen** (Ort · Person · seit-Datum,
  Chip `pt-chip--defekt` wenn `ueberfaellig`, sonst `pt-chip--neutral`; Fußzeile mit
  Sicherungsstand, nur mit `benutzer.verwalten`).
- Letzte Zeile jeder Liste führt in die vollständige Ansicht (`/pruefungen`,
  `/geraete?status=ausgegeben`) mit Chevron 18 px `--fg-subtle`.

### 2b Geräte — Tabelle

- Topbar: Titel, „204 im Bestand“, Suchfeld 320 px (`min-height: 36px`,
  `padding: 8px 12px 8px 36px`, Lupe 16 px absolut bei `left: 12px` in `--fg-subtle`),
  Primärknopf „Gerät anlegen“ mit Plus-Icon 16 px.
- Filterzeile: eigene Leiste auf `--surface` mit `padding: 12px 24px`, Pills
  `min-height: 32px`, `padding: 4px 12px`, 13 px / 500, `border-radius: 9999px`;
  aktiv `--accent`/`--accent-fg`, inaktiv `--surface` mit `--border` und `--fg-muted`.
  Zählwerte im Label („Verfügbar 126“). Danach 1 px Trenner (24 px hoch, `--border`) und
  zwei Dropdown-Pills („Ort: alle“, „Schlagwort: alle“, `border-radius: 6px`).
- Tabelle in `pt-karte` auf `--surface`.
  Spalten: `32px 88px minmax(0,1fr) 120px 190px 150px 76px`, `gap: 16px`,
  `padding: 0 20px`.
  Kopfzeile 40 px, 11 px / 600 / `0.08em` / uppercase / `--fg-subtle`, Hintergrund
  `--surface-subtle`, `border-bottom: 1px solid var(--border)`.
  Datenzeile 48 px, 14 px `--fg-body`, `border-top: 1px solid var(--hairline)`.
  Spalten: Auswahlkästchen · Nummer (mono) · Bezeichnung (ellipsis) · Status-Chip ·
  Ort · Person oder Lagerplatz · „Seit“ rechtsbündig mono; überfällige Tage in
  `--danger-fg`, leere Werte als „—“ in `--fg-subtle`.
  Kästchen: 18 × 18, `border-radius: 4px`, `1px solid var(--border-strong)` auf
  `--surface`; angehakt `--accent` mit weißem Haken (`stroke-width: 3`, 12 px).
  Hover einer Zeile: `background: var(--surface-subtle)`. Zeile klickt aufs Detail,
  das Kästchen nicht.
  Fußzeile 13 px `--fg-muted`: sichtbare Anzahl und Sortierung.
- Sortierung per Klick auf den Spaltenkopf; Filter und Suche laufen wie am Handy im
  Browser über den vollständig geladenen Store (`bestand.suche()`), **kein** Serveraufruf
  je Tastendruck, keine Paginierung.

### 2c Geräte — Mehrfachauswahl und Sammelbuchung

- Topbar zeigt „4 ausgewählt“ und „Auswahl aufheben“ (`pt-btn--still`).
- Ausgewählte Zeilen `background: var(--surface-muted)`, Kopfkästchen angehakt
  (Alle/Keine).
- Rechtes Panel: `width: 400px`, `flex: none`, `background: var(--surface)`,
  `border-left: 1px solid var(--border)`, dreigeteilt.
  Kopf `padding: 20px 24px`: `pt-mikro` „Sammelausgabe“, Titel 18 px / 600, Satz 13 px
  `--fg-muted`: „Alles oder nichts: Scheitert ein Gerät, bucht der Server keines.“
  Mitte `padding: 20px 24px`, `gap: 16px`: Zubehörliste (vorangehakt, abwählbar),
  Ziel, Empfänger, geplante Rückgabe, Notiz — exakt die Felder von
  `SammelBuchenView.vue`.
  Fuß `padding: 16px 24px`, `border-top`, Primärknopf „5 Geräte ausgeben“ + „Abbrechen“.
- Absenden: **ein** `POST /api/buchungen/sammel` mit `geraet_ids` inklusive der
  angehakten Zubehör-Ids. Fehlermeldung des Servers unverändert anzeigen (sie nennt das
  Gerät beim Namen) und dieses Gerät aus der Auswahl nehmen.

### 2d Gerätedetail

- Topbar: Zurück-Chevron 20 px in 32 × 32, Titel, Nummer (mono, 13 px `--fg-muted`),
  Status-Chip, rechts „Stammdaten bearbeiten“, „Schaden melden“ und die **vom Server
  gelieferten** Aktionen (`GET /api/scan/:nummer` → `aktionen`), Hauptaktion als
  `pt-btn--primaer`. Nie eine Aktion aus dem Frontend erfinden.
- Inhalt `grid-template-columns: 1fr 380px`, `gap: 24px`.
  Links: Standortsatz in 16 px („Liegt in **Regal C3** (Bauhof Nord).“) plus Chips
  (Warnung zuerst, dann Schlagworte); darunter Karte **Verlauf** mit vollem Zeitstrahl —
  Punkt 8 px (`--fg` beim jüngsten Eintrag, sonst `--fg-subtle`), Art fett 14 px,
  Zielzeile 13 px `--fg-muted`, Notiz auf `--surface-muted` mit `--radius-md`,
  Zeitpunkt rechts mono 13 px, Zeilen durch `--hairline` getrennt.
  Am Desktop ist der Verlauf **offen**, nicht eingeklappt wie am Handy.
  Rechts: Bildkarte (Titelbild 210 px hoch, darunter 3er-Raster Thumbnails,
  `--radius-sm`/6 px), Stammdaten als `dl` (`grid-template-columns: auto 1fr`,
  `gap: 8px 16px`, 14 px, `dt` in `--fg-muted`), Prüfungen-Karte mit Restfrist-Chips.

### 2e Ausgeben — Dialog

- Hintergrund: die Liste bleibt stehen, Overlay `rgba(10,10,10,0.32)`.
- Dialog `width: 560px`, `--radius-xl`, `1px solid var(--border)`,
  `box-shadow: var(--shadow-lg)` (`0 12px 32px rgba(10,10,10,.08)`) — Schatten nur hier.
- Kopf `padding: 20px 24px`, `border-bottom`: `pt-mikro` Buchungsart, Titel 18 px / 600,
  Zeile mono 13 px mit Nummer und aktuellem Standort, rechts Schließen-Icon 18 px in
  32 × 32.
- Körper `padding: 20px 24px`, `gap: 16px`: Warnungen als `pt-meldung--warnung` mit
  Warndreieck 18 px; Felder in `grid-template-columns: 1fr 1fr` (Ziel, Empfänger,
  geplante Rückgabe, Notiz); Zubehörliste vorangehakt.
  Bei Rücknahme statt Empfänger der Ausfall-Schalter („Gerät ist defekt — es wird
  gesperrt und lässt sich nicht mehr ausgeben“), `accent-color: var(--danger)`.
  „Baustelle ist noch nicht dabei“ nur beim Hinausgeben und nur mit
  `stammdaten.pflegen`, mit Dublettenwarnung vor dem Speichern.
- Fuß `padding: 16px 24px` auf `--surface-subtle`, `border-top`: links still
  „Zustand fotografieren“, rechts „Abbrechen“ + Primärknopf (`min-height: 40px`).
- Nach Erfolg: Dialog schließt, Zeile in der Tabelle aktualisiert sich, kurze
  Bestätigung. Die eigene Bestätigungsseite (1i) ist ein Handy-Muster und entfällt hier.
- Foto-Upload nach der Buchung an `buchung_id`; scheitert er, bleibt die Buchung gültig
  und es erscheint die Warnung „Die Buchung ist gespeichert, das Foto konnte nicht
  übertragen werden.“

### 2f Orte und Regale

- Zweispaltig: links `width: 340px`, `flex: none`, `--surface`,
  `border-right: 1px solid var(--border)`; Gruppenüberschriften („Lager und Werkstatt“,
  „Baustellen“) 11 px / 600 / `0.08em` / uppercase / `--fg-subtle`, `padding: 12px 16px`,
  oben und unten `border`. Zeilen `pt-zeile` mit `padding: 12px 16px`, Anzahl als
  `pt-chip--neutral`, ausgewählte Zeile `--surface-muted`.
  Sortierung wie im Code: Lager, dann Werkstatt, dann Baustellen alphabetisch.
- Rechts `padding: 24px`, `gap: 24px`: Kopf mit `pt-mikro` Typ, Name 24 px / 600,
  Zeile 14 px `--fg-muted` (Adresse · Anzahl Geräte · Anzahl Regalplätze), rechts
  „Ort bearbeiten“ und „Regalplatz“ (36 px).
  Karte **Regalplätze** als `grid-template-columns: repeat(3, 1fr)` mit
  `border-right: 1px solid var(--hairline)` zwischen den Feldern; Bezeichnung 14 px / 500,
  darunter mono 13 px `P-0001 · 34 Geräte`. Die Kennung vergibt weiterhin der Server.
  Karte **Bestand am Ort** als Liste (`GET /api/standorte/:id/bestand`).
- Stilllegen statt Löschen, mit Rückfrage und Hinweis auf noch stehende Geräte.
  Destruktives ist ein stiller Knopf — `pt-btn--gefahr` wird im Projekt bewusst nirgends
  verwendet.

### 2g Etiketten drucken

- `grid-template-columns: 1fr 400px`, `gap: 24px`.
- Links oben der Skalierungshinweis als `pt-meldung--warnung` — er entscheidet, ob die
  gedruckten Etiketten lesbar sind, und steht deshalb ganz oben.
- Karte **Geräte auswählen**: Kartenkopf mit Suchfeld 260 px, „Alle 204“, „Keine“.
  Tabelle `32px 96px minmax(0,1fr) 200px`, Kopf 40 px, Zeilen 44 px, gewählte Zeilen
  `--surface-muted`. Fußzeile: „3 Etiketten · 1 Bogen · Start bei Position 0“ plus
  Primärknopf „PDF öffnen“ (`POST /api/etiketten`, öffnet das PDF in einem neuen
  Fenster, **kein** automatischer Druckdialog).
- Karte **Regalplätze**: eigener Bogen, eigener Knopf — die Nummernkreise bleiben
  getrennt (`POST /api/etiketten/lagerplaetze`). Auswahl als Pills mit Kennung in mono.
- Rechts: **Nummernstand** (`GET /api/etiketten/nummern`: nächste freie Nummer,
  vergeben, gedruckt-noch-nicht-erfasst, beim Scannen aufgetaucht),
  **Etiketten auf Vorrat** (`POST /api/etiketten/vorrat`, Nummern sind ab dem Druck
  verbraucht — Rückfrage vor dem Auslösen, Bereich „10205 bis 10228“ anzeigen),
  **Bogen** (Format, erstes freies Etikett, Firmenname aus
  `GET /api/etiketten/formate`).

### 2h Gerät anlegen

- `grid-template-columns: minmax(0,700px) 380px`, `justify-content: start`.
- Formularkarte `padding: 24px`, `gap: 20px`. Pflicht ist ausschließlich die
  Bezeichnung (Feld in 16 px). Zweispaltige Paare: Hersteller/Modell,
  Seriennummer/Inventarnummer („wird vergeben“), Ort/Lagerplatz.
  Schlagworte als umschaltbare Pills (`padding: 6px 12px`, aktiv `--accent`).
  Zwei Knöpfe: „Anlegen und nächstes“ (primär) und „Anlegen und schließen“; danach
  bleiben Ort und Schlagworte stehen, die gerätespezifischen Felder werden geleert,
  Fokus zurück auf Bezeichnung.
- Rechts: **In dieser Sitzung angelegt** (mit Haken in `--success-fg`, Fußknopf
  „Etiketten für diese Geräte drucken“) und ein Hinweis auf den Excel-Weg für
  Massenerfassung (leere Zelle heißt „nicht ändern“).

### 2i iPad, quer (1024 × 768)

Gleiche Sidebar und Topbar, aber:
- Tippziele zurück auf **44 px** (Filter-Pills, Topbar-Knöpfe).
- Statt der Tabelle die Kartenliste wie am Handy, Zeilen `padding: 14px 20px`, alle
  Angaben in der Unterzeile („10004 · Donaufeld Bauteil B · T. Krenn · 21 Tage“).
- Suche als Knopf, der das Feld einblendet.

## Interaktion und Verhalten

- **Bewegung:** ein Tempo, eine Kurve — `--t-fast` 120 ms für Hover, `--t-base` 180 ms
  sonst, `--ease cubic-bezier(0.2, 0, 0, 1)`. Hover ist ein Farb- oder Border-Wechsel,
  kein Scale. `prefers-reduced-motion` ist in `basis.css` schon abgefangen.
- **Fokus:** `:focus-visible` mit `2px solid var(--fg)`, `outline-offset: 2px` — nicht
  entfernen.
- **Ladezustand:** `pt-leer` mit „Wird geladen …“; keine Skeletons.
- **Leerzustand:** ein flacher Satz in `--fg-muted`/`--fg-subtle`, keine Illustrationen.
  Beispiele aus dem Code: „Kein Gerät passt zur Suche.“, „Hier steht derzeit nichts.“,
  „Noch keine Buchung.“
- **Fehler:** `pt-meldung--fehler`, Serverwortlaut unverändert durchreichen.
  Bei der Anmeldung nichts ergänzen — der Server unterscheidet bewusst nicht, ob das
  Konto existiert.
- **Rechte:** Lesen ist kein Recht; wer angemeldet ist, sieht den ganzen Bestand.
  Knöpfe erscheinen nur mit dem passenden Recht (`geraete.pflegen`,
  `buchungen.erfassen`, `stammdaten.pflegen`, `etiketten.drucken`,
  `daten.austauschen`, `dateien.hochladen`, `dateien.verwalten`,
  `schaeden.bearbeiten`, `benutzer.verwalten`). Der eigentliche Schutz sitzt im Server.
- **Zustand:** Gerätestatus wird **nie** direkt gesetzt; Standort, Lagerplatz und Nutzer
  ergeben sich ausschließlich aus Buchungen. Buchungen sind unveränderlich, Korrekturen
  laufen als Gegenbuchung.
- **Responsiv:** unter 1024 px greift die bestehende mobile Shell mit unterer Leiste.
  Ab 1024 px Sidebar. Nur ein Umbruchpunkt, keine Zwischenstufe.
- **Scannen bleibt am Handy.** Am Desktop verweist die Übersicht darauf; die Kamera
  braucht ohnehin einen Secure Context.

## Zustand und Datenzugriff

Bestehende Stores weiterverwenden, keine neuen anlegen:

- `stores/anmeldung.ts` — Konto, `darf(recht)`, `istVerwaltung`, `passwortWechselNoetig`.
- `stores/bestand.ts` — Geräte, Standorte, Lagerplätze, Schlagworte, `suche()`,
  `ersetze()`, `ergaenzeStandort()`, `ergaenzeLagerplatz()`, `sammlung`,
  `gesammelteGeraete`, `zahlen`.

Neu am Desktop: die Zeilenauswahl der Tabelle. Sie kann auf `bestand.sammlung`
aufsetzen — dann sind Handy-Sammelmodus und Desktop-Mehrfachauswahl dieselbe Sache und
die Sammelbuchung braucht keinen zweiten Weg.

Verwendete Endpunkte: `GET /api/geraete`, `/geraete/:id`, `/geraete/:id/dateien`,
`/geraete/:id/historie`, `/geraete/:id/pruefungen`, `/geraete/:id/schaeden`,
`/geraete/:id/zubehoer`, `GET /api/scan/:code`, `POST /api/buchungen`,
`POST /api/buchungen/sammel`, `GET /api/buchungen/offen`,
`GET /api/pruefungen/faellig`, `GET /api/standorte/:id/bestand`, `POST /api/standorte`,
`PATCH /api/standorte/:id`, `POST /api/lagerplaetze`, `PATCH /api/lagerplaetze/:id`,
`POST /api/geraete`, `GET /api/etiketten/formate`, `GET /api/etiketten/nummern`,
`POST /api/etiketten`, `POST /api/etiketten/vorrat`,
`POST /api/etiketten/lagerplaetze`, `GET /api/etiketten/testbogen`,
`GET /api/benutzer`, `GET /api/sicherung/stand`.

## Design-Tokens

Quelle der Wahrheit ist `design/app/tokens.css` (identisch mit
`web/src/styles/tokens.css`). Keine neuen Werte erfinden.

**Flächen (hell):** `--surface #ffffff` · `--surface-subtle #fafafa` ·
`--surface-muted #f4f4f5` · `--border #e5e7eb` · `--border-strong #d4d4d8` ·
`--hairline #f0f0f1`

**Flächen (dunkel):** `--surface-dark #0f0f11` · `--surface-dark-subtle #18181b` ·
`--surface-dark-muted #1f1f23` · `--border-dark #27272a` ·
`--border-dark-strong #3f3f46` · `--hairline-dark #1d1d20`

**Vordergrund:** `--fg #0a0a0a` · `--fg-body #18181b` · `--fg-muted #52525b` ·
`--fg-subtle #a1a1aa` · `--fg-inverse #ffffff` (dunkel: `#f4f4f5`, `#e4e4e7`,
`#a1a1aa`, `#71717a`)

**Status, nur funktional:** `--success #22c55e` / `--success-fg #15803d` /
`--success-bg #f0fdf4` · `--warning #f59e0b` / `#b45309` / `#fffbeb` ·
`--danger #dc2626` / `#b91c1c` / `#fef2f2` · `--info-fg #1d4ed8` /
`--info-bg #eff6ff`

**Akzent = Ink.** Es gibt keine Markenfarbe: `--accent: var(--ink)` `#0a0a0a`,
`--accent-hover #1f1f23`, `--accent-fg #ffffff`. Im Dunkelmodus kippt der Akzent auf
`#f4f4f5` mit schwarzem Text.

**Schrift:** ausschließlich Systemschriften — `"Helvetica Neue", Helvetica, Arial,
system-ui, -apple-system, "Segoe UI", sans-serif`; Mono `ui-monospace, SFMono-Regular,
"SF Mono", Menlo, Consolas, monospace`. **Kein** Webfont-Import: ein Google-Fonts-Import
lief auf einem Server ohne Internet in einen Timeout. Größen 11 · 12 · 13 · 14 · 15 ·
16 · 18 · 20 · 24 · 30 · 36. Gewichte 400/500/600/700. `--tracking-tight -0.015em`,
`--tracking-label 0.08em`. Zahlen in Tabellen `font-variant-numeric: tabular-nums`.

**Abstände (4pt):** 4 · 8 · 12 · 16 · 20 · 24 · 32 · 40 · 48 · 64. Keine krummen Werte.

**Radien:** 2 · 4 · 6 · 8 · 12 · 9999 px (`--radius-xs` … `--radius-full`).
`--radius-full` nur für Chips, Pills und Status-Punkte.

**Schatten:** nur für Schwebendes. `--shadow-lg 0 12px 32px rgba(10,10,10,.08)` im
Dialog, `--shadow-focus 0 0 0 2px rgba(10,10,10,.1)` am fokussierten Feld. Sonst
Hairline-Border statt Schatten.

**Maße:** `--tippziel 48px` · `--leiste-hoehe 60px` · `--kopf-hoehe 52px` ·
`--container 780px` · Sidebar 240px · Topbar 56px.

**Dunkelmodus** ist gleichwertig umzusetzen: `html.dunkel` bzw.
`prefers-color-scheme: dark` auf `html:not(.hell)`, Umschalter liegt in `MehrView`.
Die Sidebar bleibt in beiden Modi dunkel.

## Assets

- Icons: Inline-SVG, gezeichnet im Projekt (`components/Symbol.vue`, Set
  `scan, liste, ort, mehr, zurueck, licht, suche, haken, warnung, schliessen, tastatur,
  plus, weiter`). Für den Desktop kommen im Feather-Stil dazu: `grid`, `calendar`,
  `archive`, `file`, `folder`, `settings`, `users`, `logout`, `x`. Bitte in
  `Symbol.vue` ergänzen und `symbole.ts` erweitern, nicht ad hoc ins Template zeichnen.
  Keine Icon-Library, kein Außenkontakt.
- Bilder: keine im Design. Die Fotoflächen sind Platzhalter (`<image-slot>`), im Betrieb
  `GET /api/dateien/:id` (nur mit Anmeldung).
- Beispieldaten in den Prototypen sind erfunden, aber realistisch (Wacker Neuson, Hilti,
  Bomag, Stihl, Husqvarna, Leica, Tsurumi; Baustellen in Wien, Krems, Korneuburg,
  Guntramsdorf). Etikettenfirma: SIMA INFRA Construction GmbH (`FIRMENNAME` aus `.env`).

## Sprache und Wortlaut

Deutsch (Österreich), Du-Form, Infinitiv an Knöpfen („Anlegen“, „Speichern“,
„Abbrechen“). Sentence case. Keine Emoji. Datum `31.08.2026`, Zeit 24 h.
Restfristen in Worten („seit 12 Tagen“, „heute“, „in 31 Tagen“) — im Bauhof brauchbarer
als ein Datum, das man gegen den Kalender halten muss. Sämtliche Texte in den
Prototypen sind aus dem bestehenden Code übernommen oder in seinem Ton geschrieben;
bitte unverändert übernehmen.

## Dateien in diesem Paket

```
design/Geräte-Tracker Bestand Mobil.dc.html   14 Handy-Ansichten (1a–1n), Rekonstruktion
design/Geräte-Tracker Desktop.dc.html          9 Computer-/iPad-Ansichten (2a–2i), Neuentwurf
design/GTKopf.dc.html                          Kopfzeile der Handy-Ansichten
design/GTNav.dc.html                           untere Navigationsleiste
design/GTSidebar.dc.html                       Sidebar der Computeransicht
design/app/tokens.css                          Tokens, identisch mit web/src/styles/tokens.css
design/app/basis.css                           pt-Klassen, identisch mit web/src/styles/basis.css
design/_ds/…/tokens.css                        Tokens des übergeordneten Designsystems (PATIO)
design/support.js, design/image-slot.js        Laufzeit der Prototypen, nicht übernehmen
```

Die `.dc.html`-Dateien im Browser öffnen; sie stellen sich als Rahmenboard dar. Maße und
Werte bitte aus diesem README nehmen, nicht aus dem Prototyp-Markup ableiten.

## Prüfen nach dem Bauen

```bash
npm run lint
npm --prefix web run pruefe        # vue-tsc, nicht npx
npm run pruefe:oberflaeche         # erfundene Klassen/Variablen, unbediente Routen
npm run test:web
```
